# PFS - PraiFah Smart

Deploy this app on Render.com.
